import { LegalPage } from "@/components/marketing/legal-page";

export default function Page() {
  return <LegalPage legal="terms" />;
}
